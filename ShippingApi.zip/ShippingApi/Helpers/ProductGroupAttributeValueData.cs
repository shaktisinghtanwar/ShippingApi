﻿namespace ShippingApi.Helpers
{
    public class ProductGroupAttributeValueData : BaseData
    {
        public const string PRODUCTGROUPATTRIBUTEVALUE_TABLE = "ProductGroupAttributeValue";

        public const string PRODUCTGROUPATTRIBUTEVALUEID_FIELD = "PGAttributeValueId";
        public const string PRODUCTGROUPKEY_FIELD = "ProductGroupKey";
        public const string ATTRIBUTEKEY_FIELD = "AttributeKey";
        public const string ATTRIBUTEVALUEKEY_FIELD = "AttributeValueKey";
        public const string ATTRIBUTEVALUECHOICE_FIELD = "AttributeValueChoice";
        public const string LISTORDER_FIELD = "ListOrder";
        public const string PARENTVALUE_FIELD = "ParentValue";
        public const string XTRA_FIELD = "xtra";
        public const string ISDEFAULT_FIELD = "IsDefault";

    }
}