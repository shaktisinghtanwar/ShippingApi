﻿namespace ShippingApi.Helpers
{
    public class ProductGroupAttributeValue : ProductGroupAttributeValueData
    {
        public const string XTRAKEY_IMAGENAME = "imagename";
    }
}